import type { Config } from "tailwindcss";

/**
 * Front Range Detail Studio — Tailwind theme mapped from the design tokens.
 * Dark, cinematic, cyan-accented. Pair with Framer Motion for scroll reveals.
 */
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        cyan: {
          DEFAULT: "#00BCD4",
          dark: "#008AA2",
          light: "#32EEFF",
          icon: "#04A8CB",
        },
        ink: {
          black: "#000000",
          900: "#0a0a0a",
          850: "#0d0d0d",
          800: "#111111",
          750: "#161616",
          700: "#1a1a1a",
          650: "#1e1e1e",
          form: "#2d2d2d",
          border: "#3a3a3a",
          gray: "#686868",
        },
        review: {
          google: "#e7711b",
          yelp: "#c41200",
          facebook: "#3c5b9b",
        },
      },
      fontFamily: {
        heading: ["Archivo", "sans-serif"], // 700/800 uppercase — headings & card titles
        body: ["Manrope", "sans-serif"], // 300 — body copy
        display: ["Inter", "sans-serif"], // 500 — eyebrows, labels, contact
        button: ["Michroma", "sans-serif"], // uppercase 0.05em — buttons only
      },
      borderRadius: {
        sm: "3px",
        DEFAULT: "4px",
        card: "6px",
        lg: "8px",
        xl: "16px",
        pill: "3.125rem",
      },
      boxShadow: {
        elevation: "0 3px 3px -2px rgba(0,0,0,.4), 0 3px 4px 0 rgba(0,0,0,.28)",
        card: "0 14px 40px rgba(0,0,0,.4)",
        cardHover: "0 26px 60px rgba(0,0,0,.6)",
        form: "0 24px 60px rgba(0,0,0,.45)",
        cyanGlow: "0 8px 30px rgba(0,188,212,.35)",
        cta: "0 10px 34px rgba(0,188,212,.36)",
      },
      letterSpacing: {
        tightish: "-0.1px",
        wide: "0.05em", // buttons, card titles
        wider: "0.1em",
        eyebrow: "0.16em",
        hero: "0.18em",
      },
      backgroundImage: {
        "hero-overlay":
          "linear-gradient(100deg, rgba(0,188,212,.42) 0%, rgba(0,0,0,.62) 60%, rgba(0,0,0,.78) 100%)",
        "card-overlay":
          "linear-gradient(to top, rgba(0,0,0,.86) 0%, rgba(0,0,0,.05) 62%)",
        "cyan-fill": "linear-gradient(100deg, #00BCD4 0%, #008AA2 100%)",
      },
      transitionTimingFunction: {
        reveal: "cubic-bezier(.2,.7,.2,1)",
      },
      maxWidth: {
        content: "840px",
        prose: "900px",
        wide: "1280px",
      },
    },
  },
  plugins: [],
};

export default config;
